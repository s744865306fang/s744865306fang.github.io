In order to use the code as presented here, you must compile it using
Microsoft Visual Studio 2010, and must have the latest .NET framework installed.

This code is presented under the GNU General Public Licence 3, and as such is open source,
as per the Licence.txt file.

I am not liable for any harm caused by compiling and/or using this code.